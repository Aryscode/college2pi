import React, { Component } from 'react'
import './Subnav.css'
export class Subnav extends Component {
    render() {
        return (
            <div className="Subnav">
                <div className="subnavdiv">
                    abc
                </div>
                <div>
                    abc
                </div>
                <div>
                    abc
                </div>
                <div>
                    abc
                </div>
            </div>
        )
    }
}

export default Subnav;
